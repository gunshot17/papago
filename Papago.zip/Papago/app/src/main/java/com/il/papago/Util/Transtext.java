package com.il.papago.Util;

public class Transtext {

    String translatedText;

    public Transtext(){

    }

    public Transtext(String translatedText) {
        this.translatedText = translatedText;
    }

    public String getTranslatedText() {
        return translatedText;
    }

    public void setTranslatedText(String translatedText) {
        this.translatedText = translatedText;
    }
}
